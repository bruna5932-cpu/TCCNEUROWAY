import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:neuroway/agendamentos.dart';
import 'package:neuroway/favoritos.dart';
import 'package:neuroway/menuprincipal.dart';
import 'package:neuroway/peril.dart';

class Descricaoprofi extends StatefulWidget {
  final bool abrirPerfilNaHome;
  final Map<String, dynamic>? profissional;
  final String? empresaId;

  const Descricaoprofi({
    super.key,
    this.abrirPerfilNaHome = false,
    this.profissional,
    this.empresaId,
  });

  @override
  State<Descricaoprofi> createState() => _DescricaoprofiState();
}

class _DescricaoprofiState extends State<Descricaoprofi> {
  int _currentIndex = 0;

  Map<String, dynamic>? _profissional;

  bool _carregandoProfissional = true;
  bool _isFavorited = false;
  bool _carregandoFavorito = false;

  @override
  void initState() {
    super.initState();

    _buscarProfissional();
  }

  String _textoSeguro(dynamic valor) {
    if (valor == null) {
      return '';
    }

    return valor.toString();
  }

  Future<void> _buscarProfissional() async {
    try {
      final profissionalInicial = widget.profissional;

      String profissionalUid = '';

      if (profissionalInicial != null) {
        profissionalUid = _textoSeguro(
          profissionalInicial['uid'] ??
              profissionalInicial['id'] ??
              profissionalInicial['profissionalUid'],
        );
      }

      if (profissionalUid.isEmpty) {
        if (mounted) {
          setState(() {
            _profissional = profissionalInicial;
            _carregandoProfissional = false;
          });
        }

        await _verificarFavorito();
        return;
      }

      Map<String, dynamic>? dadosProfissional;

      final documento = await FirebaseFirestore.instance
          .collection('profissionais')
          .doc(profissionalUid)
          .get();

      if (documento.exists && documento.data() != null) {
        dadosProfissional = documento.data();
      }

      if (dadosProfissional == null &&
          widget.empresaId != null &&
          widget.empresaId!.isNotEmpty) {
        final documentoEmpresa = await FirebaseFirestore.instance
            .collection('empresas')
            .doc(widget.empresaId)
            .get();

        final dadosEmpresa = documentoEmpresa.data();

        final profissionais = dadosEmpresa?['profissionais'];

        if (profissionais is List) {
          for (final item in profissionais) {
            if (item is Map) {
              final mapa = Map<String, dynamic>.from(item);

              final uidItem = _textoSeguro(
                mapa['uid'] ??
                    mapa['id'] ??
                    mapa['profissionalUid'],
              );

              if (uidItem == profissionalUid) {
                dadosProfissional = mapa;
                break;
              }
            }
          }
        }
      }

      if (mounted) {
        setState(() {
          _profissional =
              dadosProfissional ?? profissionalInicial;

          _carregandoProfissional = false;
        });
      }

      await _verificarFavorito();
    } catch (e) {
      debugPrint(
        'Erro ao buscar profissional: $e',
      );

      if (mounted) {
        setState(() {
          _profissional = widget.profissional;
          _carregandoProfissional = false;
        });
      }

      await _verificarFavorito();
    }
  }

  String _obterProfissionalUid() {
    final profissional = _profissional;

    if (profissional == null) {
      return '';
    }

    return _textoSeguro(
      profissional['uid'] ??
          profissional['id'] ??
          profissional['profissionalUid'],
    );
  }

  Future<void> _verificarFavorito() async {
    final usuario = FirebaseAuth.instance.currentUser;

    final profissionalUid = _obterProfissionalUid();

    if (usuario == null ||
        profissionalUid.isEmpty) {
      if (mounted) {
        setState(() {
          _isFavorited = false;
        });
      }

      return;
    }

    try {
      final consulta = await FirebaseFirestore.instance
          .collection('favoritos')
          .where(
            'usuarioId',
            isEqualTo: usuario.uid,
          )
          .where(
            'tipo',
            isEqualTo: 'profissional',
          )
          .where(
            'profissionalUid',
            isEqualTo: profissionalUid,
          )
          .limit(1)
          .get();

      if (mounted) {
        setState(() {
          _isFavorited = consulta.docs.isNotEmpty;
        });
      }
    } catch (e) {
      debugPrint(
        'Erro ao verificar favorito: $e',
      );
    }
  }

  Future<void> _alternarFavorito() async {
    if (_carregandoFavorito) {
      return;
    }

    final usuario = FirebaseAuth.instance.currentUser;

    if (usuario == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Faça login para adicionar favoritos.',
            ),
          ),
        );
      }

      return;
    }

    final profissional = _profissional;

    if (profissional == null) {
      return;
    }

    final profissionalUid = _obterProfissionalUid();

    if (profissionalUid.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Não foi possível identificar este profissional.',
            ),
          ),
        );
      }

      return;
    }

    if (mounted) {
      setState(() {
        _carregandoFavorito = true;
      });
    }

    try {
      final favoritosRef =
          FirebaseFirestore.instance.collection('favoritos');

      final consulta = await favoritosRef
          .where(
            'usuarioId',
            isEqualTo: usuario.uid,
          )
          .where(
            'tipo',
            isEqualTo: 'profissional',
          )
          .where(
            'profissionalUid',
            isEqualTo: profissionalUid,
          )
          .get();

      if (consulta.docs.isNotEmpty) {
        for (final documento in consulta.docs) {
          await documento.reference.delete();
        }

        if (mounted) {
          setState(() {
            _isFavorited = false;
          });

          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Profissional removido dos favoritos.',
              ),
              duration: Duration(seconds: 1),
            ),
          );
        }
      } else {
        final nome = _textoSeguro(
          profissional['nome'] ??
              profissional['name'],
        );

        final especialidade = _textoSeguro(
          profissional['especialidade'] ??
              profissional['profissao'] ??
              profissional['profissão'] ??
              profissional['categoria'],
        );

        final descricao = _textoSeguro(
          profissional['descricao'] ??
              profissional['descricaoProfissional'] ??
              profissional['bio'] ??
              profissional['sobre'],
        );

        final foto = _textoSeguro(
          profissional['foto'] ??
              profissional['fotoUrl'] ??
              profissional['imagem'],
        );

        final empresaId = _textoSeguro(
          widget.empresaId,
        );

        await favoritosRef.add({
          'usuarioId': usuario.uid,
          'tipo': 'profissional',
          'profissionalUid': profissionalUid,
          'empresaId': empresaId,
          'nome': nome,
          'especialidade': especialidade,
          'profissao': especialidade,
          'descricao': descricao,
          'foto': foto,
          'criadoEm': FieldValue.serverTimestamp(),
        });

        if (mounted) {
          setState(() {
            _isFavorited = true;
          });

          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Profissional adicionado aos favoritos!',
              ),
              duration: Duration(seconds: 1),
            ),
          );
        }
      }
    } catch (e) {
      debugPrint(
        'Erro ao alterar favorito: $e',
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Erro ao alterar favorito: $e',
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _carregandoFavorito = false;
        });
      }
    }
  }

  List<Widget> get _paginas => [
        _buildPerfilConteudo(),
        const Favoritos(),
        const Agendamentos(),
        const Perfil(),
      ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: IndexedStack(
          index: _currentIndex,
          children: _paginas,
        ),
      ),
      bottomNavigationBar: CustomBottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
      ),
    );
  }

  Widget _buildPerfilConteudo() {
    if (_carregandoProfissional) {
      return const Center(
        child: CircularProgressIndicator(
          color: Color(0xFF98B9A6),
        ),
      );
    }

    final profissional = _profissional ?? {};

    final nome = _textoSeguro(
      profissional['nome'] ??
          profissional['name'],
    );

    final nomeFinal =
        nome.isEmpty ? 'Profissional' : nome;

    final especialidade = _textoSeguro(
      profissional['especialidade'] ??
          profissional['profissao'] ??
          profissional['profissão'] ??
          profissional['categoria'],
    );

    final descricao = _textoSeguro(
      profissional['descricao'] ??
          profissional['descricaoProfissional'] ??
          profissional['bio'] ??
          profissional['sobre'],
    );

    final descricaoFinal = descricao.isEmpty
        ? 'Profissional cadastrado no estabelecimento.'
        : descricao;

    final foto = _textoSeguro(
      profissional['foto'] ??
          profissional['fotoUrl'] ??
          profissional['imagem'],
    );

    final profissionalUid = _obterProfissionalUid();

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ProfileHeaderSection(
            nome: nomeFinal,
            especialidade: especialidade,
            foto: foto,
            isFavorited: _isFavorited,
            carregandoFavorito: _carregandoFavorito,
            onFavoritar: _alternarFavorito,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 20,
            ),
            child: Text(
              descricaoFinal,
              style: const TextStyle(
                fontSize: 15,
                height: 1.4,
                color: Colors.black87,
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 20,
              vertical: 10,
            ),
            child: Divider(
              color: Colors.black45,
              thickness: 1,
            ),
          ),
          CommentsSection(
            profissionalUid: profissionalUid,
            empresaId: widget.empresaId,
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class CustomBottomNavigationBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const CustomBottomNavigationBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        border: Border(
          top: BorderSide(
            color: Color(0xFFE0E0E0),
            width: 1,
          ),
        ),
      ),
      child: BottomNavigationBar(
        currentIndex: currentIndex,
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        selectedItemColor: Colors.black,
        unselectedItemColor: const Color(0xFF9E9E9E),
        showSelectedLabels: false,
        showUnselectedLabels: false,
        onTap: onTap,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home_filled,
              size: 28,
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.favorite,
              size: 28,
            ),
            label: 'Favoritos',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.calendar_month,
              size: 28,
            ),
            label: 'Agenda',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.person,
              size: 28,
            ),
            label: 'Perfil',
          ),
        ],
      ),
    );
  }
}

class ProfileHeaderSection extends StatelessWidget {
  final String nome;
  final String especialidade;
  final String foto;
  final bool isFavorited;
  final bool carregandoFavorito;
  final VoidCallback onFavoritar;

  const ProfileHeaderSection({
    super.key,
    required this.nome,
    required this.especialidade,
    required this.foto,
    required this.isFavorited,
    required this.carregandoFavorito,
    required this.onFavoritar,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned(
          top: 45,
          left: 10,
          child: IconButton(
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.black,
              size: 28,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),

        Positioned(
          top: 95,
          right: 15,
          child: IconButton(
            icon: carregandoFavorito
                ? const SizedBox(
                    width: 25,
                    height: 25,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.black,
                    ),
                  )
                : Icon(
                    isFavorited
                        ? Icons.favorite
                        : Icons.favorite_border,
                    color: isFavorited
                        ? Colors.red
                        : Colors.black,
                    size: 28,
                  ),
            onPressed:
                carregandoFavorito
                    ? null
                    : onFavoritar,
          ),
        ),

        Padding(
          padding: const EdgeInsets.only(
            top: 45,
            left: 45,
            right: 45,
            bottom: 10,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.grey[600],
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white,
                    width: 4,
                  ),
                ),
                child: foto.isNotEmpty
                    ? ClipOval(
                        child: Image.network(
                          foto,
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                          errorBuilder: (
                            context,
                            error,
                            stackTrace,
                          ) {
                            return const Icon(
                              Icons.person,
                              size: 70,
                              color: Colors.white,
                            );
                          },
                        ),
                      )
                    : const Icon(
                        Icons.person,
                        size: 70,
                        color: Colors.white,
                      ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      nome,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        height: 1.1,
                        color: Colors.black,
                      ),
                    ),
                    if (especialidade.isNotEmpty)
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 4),
                        child: Text(
                          especialidade,
                          maxLines: 1,
                          overflow:
                              TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 14,
                            color: Colors.grey,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    const SizedBox(height: 6),
                    Row(
                      children: List.generate(
                        5,
                        (index) => const Icon(
                          Icons.star,
                          color: Colors.amber,
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class CommentsSection extends StatelessWidget {
  final String profissionalUid;
  final String? empresaId;

  const CommentsSection({
    super.key,
    required this.profissionalUid,
    required this.empresaId,
  });

  CollectionReference<Map<String, dynamic>>?
      _comentariosRef() {
    if (empresaId == null ||
        empresaId!.isEmpty ||
        profissionalUid.isEmpty) {
      return null;
    }

    return FirebaseFirestore.instance
        .collection('empresas')
        .doc(empresaId)
        .collection('comentarios');
  }

  Future<void> _abrirComentario(
    BuildContext context,
  ) async {
    final controller = TextEditingController();

    await showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Faça um comentário',
          ),
          content: TextField(
            controller: controller,
            maxLines: 5,
            maxLength: 300,
            decoration: const InputDecoration(
              hintText:
                  'Digite seu comentário...',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                );
              },
              child: const Text(
                'Cancelar',
              ),
            ),
            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(0xFF98B9A6),
                foregroundColor:
                    Colors.white,
              ),
              onPressed: () async {
                final texto =
                    controller.text.trim();

                if (texto.isEmpty) {
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Digite um comentário.',
                      ),
                    ),
                  );
                  return;
                }

                if (empresaId == null ||
                    empresaId!.isEmpty) {
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Erro: empresa não identificada.',
                      ),
                    ),
                  );
                  return;
                }

                if (profissionalUid.isEmpty) {
                  ScaffoldMessenger.of(
                    context,
                  ).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Erro: profissional não identificado.',
                      ),
                    ),
                  );
                  return;
                }

                final usuario =
                    FirebaseAuth
                        .instance
                        .currentUser;

                String nome = 'Usuário';

                if (usuario != null) {
                  if (usuario.displayName !=
                          null &&
                      usuario.displayName!
                          .trim()
                          .isNotEmpty) {
                    nome = usuario
                        .displayName!
                        .trim();
                  } else if (usuario.email !=
                      null) {
                    nome = usuario.email!
                        .split('@')
                        .first;
                  }
                }

                try {
                  final ref =
                      FirebaseFirestore
                          .instance
                          .collection(
                            'empresas',
                          )
                          .doc(
                            empresaId,
                          )
                          .collection(
                            'comentarios',
                          );

                  await ref.add({
                    'profissionalUid':
                        profissionalUid,
                    'nome': nome,
                    'comentario': texto,
                    'likes': 0,
                    'dislikes': 0,
                    'criadoEm':
                        FieldValue
                            .serverTimestamp(),
                  });

                  if (dialogContext
                      .mounted) {
                    Navigator.pop(
                      dialogContext,
                    );
                  }

                  if (context.mounted) {
                    ScaffoldMessenger.of(
                      context,
                    ).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Comentário publicado com sucesso!',
                        ),
                      ),
                    );
                  }
                } catch (e) {
                  debugPrint(
                    'Erro ao publicar comentário: $e',
                  );

                  if (context.mounted) {
                    ScaffoldMessenger.of(
                      context,
                    ).showSnackBar(
                      SnackBar(
                        content: Text(
                          'Erro ao publicar comentário: $e',
                        ),
                      ),
                    );
                  }
                }
              },
              child: const Text(
                'Publicar',
              ),
            ),
          ],
        );
      },
    );

    controller.dispose();
  }

  Future<void> _alterarReacao(
    DocumentSnapshot<Map<String, dynamic>>
        comentario,
    String campo,
  ) async {
    try {
      final ref = comentario.reference;

      await FirebaseFirestore.instance
          .runTransaction(
        (transaction) async {
          final snapshot =
              await transaction.get(ref);

          if (!snapshot.exists) return;

          final dados =
              snapshot.data();

          if (dados == null) return;

          final valorAtual =
              dados[campo] is num
                  ? (dados[campo] as num)
                  : 0;

          transaction.update(
            ref,
            {
              campo:
                  valorAtual.toInt() + 1,
            },
          );
        },
      );
    } catch (e) {
      debugPrint(
        'Erro ao alterar reação: $e',
      );
    }
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    final ref = _comentariosRef();

    return Padding(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 20,
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'Comentários',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight:
                      FontWeight.bold,
                ),
              ),
              const SizedBox(width: 6),
              Icon(
                Icons.chat_bubble_outline,
                size: 18,
                color: Colors.grey[700],
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (ref == null)
            const Text(
              'Não foi possível carregar os comentários.',
              style: TextStyle(
                color: Colors.grey,
              ),
            )
          else
            StreamBuilder<
                QuerySnapshot<
                    Map<String, dynamic>>>(
              stream: ref
                  .where(
                    'profissionalUid',
                    isEqualTo:
                        profissionalUid,
                  )
                  .snapshots(),
              builder:
                  (context, snapshot) {
                if (snapshot
                        .connectionState ==
                    ConnectionState.waiting) {
                  return const Padding(
                    padding:
                        EdgeInsets.symmetric(
                      vertical: 20,
                    ),
                    child: Center(
                      child:
                          CircularProgressIndicator(
                        color:
                            Color(0xFF98B9A6),
                      ),
                    ),
                  );
                }

                if (snapshot.hasError) {
                  return Padding(
                    padding:
                        const EdgeInsets.symmetric(
                      vertical: 10,
                    ),
                    child: Text(
                      'Erro ao carregar comentários:\n${snapshot.error}',
                      style:
                          const TextStyle(
                        color: Colors.red,
                        fontSize: 12,
                      ),
                    ),
                  );
                }

                final comentarios =
                    snapshot.data?.docs ??
                        [];

                if (comentarios.isEmpty) {
                  return const Padding(
                    padding:
                        EdgeInsets.symmetric(
                      vertical: 10,
                    ),
                    child: Text(
                      'Ainda não há comentários para este profissional.',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 14,
                      ),
                    ),
                  );
                }

                comentarios.sort(
                  (a, b) {
                    final dataA =
                        a.data()['criadoEm'];
                    final dataB =
                        b.data()['criadoEm'];

                    if (dataA is Timestamp &&
                        dataB is Timestamp) {
                      return dataB.compareTo(
                        dataA,
                      );
                    }

                    return 0;
                  },
                );

                return Column(
                  children:
                      comentarios.map(
                    (comentario) {
                      final dados =
                          comentario.data();

                      final nome =
                          dados['nome']
                                  ?.toString() ??
                              'Usuário';

                      final texto =
                          dados['comentario']
                                  ?.toString() ??
                              '';

                      final likes =
                          dados['likes'] is num
                              ? (dados['likes']
                                      as num)
                                  .toInt()
                              : 0;

                      final dislikes =
                          dados['dislikes'] is num
                              ? (dados[
                                      'dislikes']
                                  as num)
                                  .toInt()
                              : 0;

                      return Padding(
                        padding:
                            const EdgeInsets.only(
                          bottom: 12,
                        ),
                        child:
                            CommentCard(
                          author: nome,
                          content: texto,
                          likes: likes,
                          dislikes:
                              dislikes,
                          onLike: () {
                            _alterarReacao(
                              comentario,
                              'likes',
                            );
                          },
                          onDislike: () {
                            _alterarReacao(
                              comentario,
                              'dislikes',
                            );
                          },
                        ),
                      );
                    },
                  ).toList(),
                );
              },
            ),
          const SizedBox(height: 4),
          OutlinedButton(
            onPressed: () {
              _abrirComentario(context);
            },
            style:
                OutlinedButton.styleFrom(
              foregroundColor:
                  Colors.black,
              side:
                  const BorderSide(
                color: Colors.grey,
              ),
              shape:
                  RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(
                  8,
                ),
              ),
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 8,
              ),
            ),
            child: const Text(
              'Faça um comentário!',
              style: TextStyle(
                fontWeight:
                    FontWeight.bold,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CommentCard extends StatelessWidget {
  final String author;
  final String content;
  final int likes;
  final int dislikes;
  final VoidCallback onLike;
  final VoidCallback onDislike;

  const CommentCard({
    super.key,
    required this.author,
    required this.content,
    required this.likes,
    required this.dislikes,
    required this.onLike,
    required this.onDislike,
  });

  @override
  Widget build(
    BuildContext context,
  ) {
    return Container(
      width: double.infinity,
      padding:
          const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius:
            BorderRadius.circular(16),
        border: Border.all(
          color: Colors.grey.shade300,
        ),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Text(
            author,
            style: const TextStyle(
              fontWeight:
                  FontWeight.bold,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            content,
            style: const TextStyle(
              fontSize: 13,
              height: 1.3,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment:
                MainAxisAlignment.end,
            children: [
              InkWell(
                onTap: onLike,
                child: Row(
                  children: [
                    Icon(
                      Icons
                          .thumb_up_outlined,
                      size: 14,
                      color:
                          Colors.grey[700],
                    ),
                    const SizedBox(
                        width: 4),
                    Text(
                      '$likes',
                      style:
                          const TextStyle(
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                  width: 16),
              InkWell(
                onTap: onDislike,
                child: Row(
                  children: [
                    Icon(
                      Icons
                          .thumb_down_outlined,
                      size: 14,
                      color:
                          Colors.grey[700],
                    ),
                    const SizedBox(
                        width: 4),
                    Text(
                      '$dislikes',
                      style:
                          const TextStyle(
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}